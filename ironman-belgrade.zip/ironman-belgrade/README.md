# Ironman 70.3 Belgrade — Training Plan

Personal 21-week periodized training plan for Ironman 70.3 Belgrade, 13 September 2026.

Single-page web app, zero dependencies, all state stored locally in the browser. Synthesised from Matt Fitzgerald (Triathlete), Joe Friel, the official IRONMAN 16-week plan, MyProCoach, Triathlon Magazine Canada and 80/20 Endurance — adapted for a strong runner, ok cyclist, developing swimmer, with CFA and engineering exam windows, Peru travel, and a full-time job start baked into the periodization.

## Features

- 21 weeks × 7 days × multiple workouts per day
- Tap circle to mark sessions done, with satisfying animations
- Drag and drop workouts between days of the same week (press-and-hold on mobile)
- Progress tracked across total hours, by discipline, and per week
- Phase view for quick macro navigation
- Guide with intensity zones and periodization principles

## Running it

It's a single `index.html` — open it in any modern browser. No build, no server, no install.

## Hosting

Deployed via GitHub Pages from the `main` branch root. All files served statically.

## Known issues / pending changes

Tracked for the next iteration:

1. Drag-and-drop state tracking can duplicate a workout under certain conditions — needs stable workout IDs instead of position-based keying
2. Progress does not persist across browser sessions in the current version — needs `localStorage` instead of the sandboxed storage API
3. Custom home-screen icon with apple-touch-icon meta tags
4. Delete-workout capability (not just move)

## Race

- **Event:** Ironman 70.3 Belgrade
- **Date:** 13 September 2026
- **Distances:** 1.9 km swim / 90 km bike / 21.1 km run
